#ifndef directory_h
#define directory_h

#include <stdio.h>
typedef struct{
    unsigned short ino;
    char name[14];
} dir_t;

#endif /* directory_h */
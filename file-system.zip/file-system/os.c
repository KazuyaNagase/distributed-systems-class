#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "util.h"
#include "inode.h"
#include "os.h"
#include "directory.h"

os v6;

void boot(const char *img_name){
    v6.img = load_file(img_name);
    v6.root = v6.current_inode = read_inode(1);
}

void shutdown(){
    free_file(v6.img);
    exit(0);
}

unsigned char *read_block(int block_num){
    return &v6.img[BLOCKSIZE * block_num];
}

void print_file_info(inode_t *inode){
    fprintf(stderr, "%c", inode->i_mode & IFDIR ? 'd' : '-');
    fprintf(stderr, "%c", inode->i_mode & 0400 ? 'r' : '-');
    fprintf(stderr, "%c", inode->i_mode & 0200 ? 'w' : '-');
    fprintf(stderr, "%c", inode->i_mode & 0100 ? 'x' : '-');
    fprintf(stderr, "%c", inode->i_mode & 040 ? 'r' : '-');
    fprintf(stderr, "%c", inode->i_mode & 020 ? 'w' : '-');
    fprintf(stderr, "%c", inode->i_mode & 010 ? 'x' : '-');
    fprintf(stderr, "%c", inode->i_mode & 04 ? 'r' : '-');
    fprintf(stderr, "%c", inode->i_mode & 02 ? 'w' : '-');
    fprintf(stderr, "%c", inode->i_mode & 01 ? 'x' : '-');
    fprintf(stderr, " %8d ", inode->i_size1 + (inode->i_size0 << 16));
}

void debug_inode(inode_t *inode){
    fprintf(stderr, "i_mode = %04x\n", inode->i_mode);
    fprintf(stderr, "i_nlink = %02x\n", inode->i_nlink);
    fprintf(stderr, "i_uid = %02x\n", inode->i_uid);
    fprintf(stderr, "i_gid = %02x\n", inode->i_gid);
    fprintf(stderr, "i_size1 = %04x\n", inode->i_size1);
    fprintf(stderr, "i_size0 = %02x\n", inode->i_size0);
    fprintf(stderr, "\n");
}

inode_t *read_inode(int inode_num){
    inode_t *inode;
    int block_num = (inode_num + 31) / 16;
    unsigned char *block_data = read_block(block_num);
    int offset = 32 * ((inode_num + 31) % 16);
    inode = (inode_t *)(block_data + offset);
    return inode;
}

int find_next_inode_num(inode_t *from, const char *next_inode_name){
    if (next_inode_name == NULL)
        return -1;
    for (int i = 0; i < 8 && from->i_addr[i] != 0; i++){
        unsigned char *storage_block = read_block(from->i_addr[i]);
        for (size_t offset = 0; offset < BLOCKSIZE; offset += sizeof(dir_t)){
            dir_t *dir = (dir_t *)&storage_block[offset];
            if (!strcmp(dir->name, next_inode_name))
                return dir->ino;
        }
    }
    return -1;
}

inode_t *namei(const char *inode_path){
    inode_t *inode;
    if (inode_path == NULL)
        return NULL;
    if (inode_path[0] == '/'){
        inode = v6.root;
        inode_path++;
    }
    else
        inode = v6.current_inode;
    char path[256];
    strcpy(path, inode_path);
    char *split_name[256];
    int count = split(path, "/", split_name);
    for (int move_cnt = 0; move_cnt < count; move_cnt++){
        int next_ino = find_next_inode_num(inode, split_name[move_cnt]);
        if (next_ino == -1)
            return NULL;
        inode = read_inode(next_ino);
    }
    return inode;
}

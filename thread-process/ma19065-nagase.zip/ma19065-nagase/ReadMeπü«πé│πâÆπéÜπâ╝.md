確認方法
gcc 'fileName'
./a.out
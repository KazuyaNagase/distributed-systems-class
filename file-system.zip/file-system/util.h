#ifndef util_h
#define util_h

#include <stdio.h>
unsigned char *load_file(const char *filename);
void free_file(unsigned char *data);
int split(char *str, const char *delim, char *outlist[]);
#endif /* util_h */

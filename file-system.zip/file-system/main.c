#include <stdio.h>
#include "os.h"
#include "shell.h"

int main(int argc, char *argv[]){
    const char *file_name = "img/v6root";
    boot(file_name);
    v6sh_run();
    shutdown();
    return 0;
}

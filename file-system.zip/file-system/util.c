#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define MAXITEM 10

unsigned char *load_file(const char *filename){
    int fd;
    struct stat stbuf;
    if (stat(filename, &stbuf) != 0){
        perror("stat");
        exit(1);
    }
    if ((fd = open(filename, O_RDONLY)) == -1){
        perror("open");
        printf("a");
        exit(1);
    }
    long filesize = stbuf.st_size;
    unsigned char *data = (unsigned char *)malloc(filesize + 1);
    memset(data, 0, filesize);
    read(fd, data, filesize);
    data[filesize] = '\0';
    close(fd);
    return data;
}

void free_file(unsigned char *data){
    free(data);
    return;
}

int split(char *str, const char *delim, char *outlist[]){
    char *tk;
    int cnt = 0;
    tk = strtok(str, delim);
    while (tk != NULL && cnt < MAXITEM){
        outlist[cnt++] = tk;
        tk = strtok(NULL, delim);
    }
    return cnt;
}

#include <stdio.h>
#include "os.h"
#include "directory.h"
#include "util.h"
#include "inode.h"
#include "directory.h"

void ls(const char *option){
    //osとshellの機能 分離するのだるいのでベタがき
    for (int i = 0; i < 8 && v6.current_inode->i_addr[i] != 0; i++){
        unsigned char *storage_block = read_block(v6.current_inode->i_addr[i]);
        for (size_t offset = 0; offset < BLOCKSIZE; offset += sizeof(dir_t)){
            dir_t *dir = (dir_t *)&storage_block[offset];
            if (dir->ino == 0)
                continue;
            if (option != NULL){
                if (!strcmp(option, "-l")){
                    inode_t *inode = read_inode(dir->ino);
                    print_file_info(inode);
                }
            }
            printf("%s\n", dir->name);
        }
    }
}

void cd(const char *dir_name)
{
    if (dir_name == NULL){
        printf("usage: cd [filename] \n");
        return;
    }
    inode_t *next_inode = namei(dir_name);
    if (next_inode == NULL){
        printf("no such directory : %s\n", dir_name);
        return;
    }
    if ((next_inode->i_mode & IFDIR) == IFDIR){
        v6.current_inode = next_inode;
        return;
    }
    else{
        printf("%s is not directory\n", dir_name);
        return;
    }
}

void v6sh_run(){
    while (true){
        printf("v6sh:");
        char str[64] = {0};
        char *commands[10] = {0};
        fgets(str, sizeof(str), stdin);
        str[strlen(str) - 1] = ' ';
        split(str, " ", commands);
        if (!strcmp(str, "exit"))
            break;
        else if (!strcmp(commands[0], "ls"))
            ls(commands[1]);
        else if (!strcmp(commands[0], "cd"))
            cd(commands[1]);
        else
            printf("command not found: %s\n", commands[0]);
    }
}

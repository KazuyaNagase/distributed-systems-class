#ifndef os_h
#define os_h

#include "inode.h"

typedef struct os{
    unsigned char *img;
    inode_t *current_inode;
    inode_t *root;
} os;

void boot(const char *img_name);
void shutdown();
inode_t *namei(const char *inode_path);
int find_next_inode_num(inode_t *from, const char *next_inode_name);
inode_t *read_inode(int inode_num);
void print_file_info(inode_t *inode);
unsigned char *read_block(int block_num);

extern os v6;

#endif /* os_h */

## 実行方法

1. Q1の実行方法

```gcc prog-q1.c```

 ```./a.out  ```

2. Q2の実行方法

```gcc prog-q1.c```

 ```./a.out  ```

3. Q3の実行方法

```gcc prog-q1.c```

 ```./a.out  ```



実行結果

![実行結果](./%E5%AE%9F%E8%A1%8C%E7%B5%90%E6%9E%9C.png)